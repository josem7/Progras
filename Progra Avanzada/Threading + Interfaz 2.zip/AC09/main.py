import threading as thr
import time
from itertools import chain
from random import randint, random


global_lock = thr.Lock()

class Equipo(thr.Thread):

    def __init__(self, nombre, señal, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.nombre = nombre
        self.hacker = Hacker(nombre, randint(4, 12))
        self.cracker = Cracker(nombre)
        self.daemon = True
        self.señal = señal


    def run(self):
        self.hacker.start()
        self.cracker.start()
        self.hacker.join()
        self.cracker.join()
        print(f"Ganador Equipo: {self.nombre}")
        self.señal.set()
        return


class Hacker(thr.Thread):

    def __init__(self, equipo, tiempo, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.equipo = equipo
        self.tiempo = tiempo
        self.daemon = True
        self.desencripto = False


    def run(self):
        time.sleep(self.tiempo)
        print(f"Hacker terminó, equipo:{self.equipo}")
        self.desencripto = True
        return


class Cracker(thr.Thread):

    def __init__(self, equipo,*args, **kwargs):
        super().__init__(*args, **kwargs)
        self.equipo = equipo
        self.victima = False
        self.lineas = 50
        self.lineas_escritas = 0
        self.daemon = True

    @property
    def lineas(self):
        return self._lineas

    @lineas.setter
    def lineas(self, value):
        self._lineas = value
        if self._lineas < 0:
            self._lineas = 0

    def run(self):
        while self._lineas:
            lineas = randint(5, 15)
            time.sleep(1)
            if random() < 0.2:
                print(f"victima cracker equipo: {self.equipo}")
                self.victima = True
            if self.victima:
                with global_lock:
                    NebilLockbottom(self)
            else:
                self.lineas_escritas += lineas
                self.lineas -= lineas
        print(f"cracker terminó, equipo:{self.equipo}")
        self.lineas_escritas = 50
        return


def NebilLockbottom(cracker):
    print(f"ayudando cracker equipo: {cracker.equipo}")
    time.sleep(randint(1, 3))
    cracker.victima = False
    print(f"terminando cracker equipo: {cracker.equipo}")


class Mision:
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.señal = thr.Event()
        self.e1 = Equipo("1", self.señal)
        self.e2 = Equipo("2", self.señal)
        self.e3 = Equipo("3", self.señal)

    def run(self):
        self.e1.start()
        self.e2.start()
        self.e3.start()
        self.señal.wait()
        print(f"{self.e1.nombre}: hacker desencripto: "
              f"{self.e1.hacker.desencripto}, lineas cracker: "
              f"{self.e1.cracker.lineas_escritas} ")
        print(f"{self.e2.nombre}: hacker desencripto: "
              f"{self.e2.hacker.desencripto}, lineas cracker: "
              f"{self.e2.cracker.lineas_escritas} ")
        print(f"{self.e3.nombre}: hacker desencripto: "
              f"{self.e3.hacker.desencripto}, lineas cracker: "
              f"{self.e3.cracker.lineas_escritas} ")
        return


def desencriptar(nombre_archivo):
    """
    Esta simple (pero útil) función te permite descifrar un archivo encriptado.
    Dado el path de un archivo, devuelve un string del contenido desencriptado.
    """

    with open(nombre_archivo, "r", encoding="utf-8") as archivo:
        murcielago, numeros = "murcielago", "0123456789"
        dic = dict(chain(zip(murcielago, numeros), zip(numeros, murcielago)))
        return "".join(
            dic.get(char, char) for linea in archivo for char in linea.lower())


if __name__ == "__main__":
    m1 = Mision()
    m1.run()
