# Acá va lo relacionado con el procesamiento de datos
from PyQt5.QtCore import QObject, pyqtSignal
from PyQt5.Qt import QTest


def nombre_valido(nombre):

    return nombre.isalpha() and len(nombre) > 6

class Character(QObject):

    update_position_signal = pyqtSignal(dict)

    def __init__(self,  parent, x, y):
        super().__init__()
        self.jumping = False
        self._x = x
        self._y = y

        self.update_position_signal.connect(parent.update_position)

    @property
    def y(self):
        return self._y

    @y.setter
    def y(self, value):
        """
        Envía la señal update_position al cambiar la coordenada y.
        :param value: int
        :return: none
        """
        if 8 < value < 583:
            self._y = value
            self.update_position_signal.emit({'x': self.x, 'y': self.y})

    @property
    def x(self):
        return self._x

    @x.setter
    def x(self, value):
        """
        Chequea que la coordenada x se encuentre dentro de los parámetros y envía la señal
        update_position con las nuevas coordenadas.
        :param value: int
        :return: none
        """
        if 13 < value < 530:
            self._x = value
            self.update_position_signal.emit({'x': self.x, 'y': self.y})

    def move(self, event):
        """
        Función que maneja los eventos de movimiento (L, R) y de salto.
        :param event: str
        :return: none
        """
        if event == 'D':
            self.x += 5
            self.direction = 'R'
        if event == 'S':
            self.y += 5
            self.direction = 'D'
        if event == 'A':
            self.x -= 5
            self.direction = 'L'
        if event == 'W':
            self.y -= 5
            self.direction = 'U'
