# Acá va lo relacionado con los eventos, es decir,
# la comunicacion entre el backend y el frontend
