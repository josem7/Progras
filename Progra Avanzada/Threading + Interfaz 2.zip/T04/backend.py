import os
import hashlib
from base64 import b64encode, b64decode
from PyQt5.QtCore import QObject, pyqtSignal
from math import sin, cos, radians, pi
import random
from time import sleep


def cargar_db_usuarios():
    l_usuarios = []
    with open("db/db.csv") as archivo:
        for linea in archivo:
            l_usuarios.append(linea.strip().split(",")[0])
    return l_usuarios

def cargar_db():
    lista = []
    with open("db/db.csv") as archivo:
        for linea in archivo:
            lista.append(linea.strip().split(","))
    return lista

def guardar_db(nombre, contra, salt):
    with open("db/db.csv", "a") as archivo:
        print(nombre, contra, salt, sep=",", file=archivo)


def encriptar(contra: str):
    contra1 = contra
    contra = str.encode(contra)
    salt = os.urandom(8)
    print(salt)
    contra = contra + salt
    contra = hashlib.sha3_256(contra).digest()
    return b64encode(salt).decode('utf-8'), b64encode(contra).decode('utf-8')


def decriptar(contra: str, salt):
    contra = str.encode(contra)
    salt = b64decode(salt)
    contra = contra + salt
    contra = hashlib.sha3_256(contra).digest()
    return b64encode(contra).decode('utf-8')


def registro(nombre, contra):
    l_usario = cargar_db_usuarios()
    if "," in nombre:
        print("A")
        return False
    if nombre is None or contra is None:
        return False
    if nombre in l_usario:
        return False
    salt, contra = encriptar(contra)

    guardar_db(nombre, contra, salt)
    return True


def cargar_usuario(usuario, contra):
    l_usuario_contra = cargar_db()
    for i in l_usuario_contra:
        if usuario in i:
            _, contra_guardada, salt = i
            contra = decriptar(contra, salt)
            if contra == contra_guardada:
                return True
            else:
                return False


registro("a", "b")
cargar_usuario("a", "b")


class Character(QObject):

    update_position_signal = pyqtSignal(dict)

    def __init__(self,  parent, x, y):
        super().__init__()
        self.jumping = False
        self._x = x
        self._teta = 0
        self._y = y
        self._stop = 0
        self.radius = 2.5

        self.update_position_signal.connect(parent.update_position)

    @property
    def y(self):
        return self._y

    @y.setter
    def y(self, value):
        if 20 < value < 580:
            self._y = value


    @property
    def x(self):
        return self._x

    @x.setter
    def x(self, value):
        if 20 < value < 580:
            self._x = value

    @property
    def teta(self):
        return self._teta

    @teta.setter
    def teta(self, value):
        if 0 < value < 360:
            self._teta = value
        elif value <= 0:
            self._teta = 360 + value
        elif value >= 360:
            self._teta = 0 + value

    @property
    def stop(self):
        return self._stop

    @stop.setter
    def stop(self, value):
        if value >= 0:
            self._stop = value


    def collision(self):
        sensors_x = [int(round(
            self.x + self.radius * cos(self.teta + pi * i / 6)))
            for i in range(-2, 3)]
        sensors_y = [int(round(
            self.y - self.radius * sin(self.teta + pi * i / 6)))
            for i in range(-2, 3)]

        Y = {x for x in zip(sensors_x, sensors_y)}
        return list(Y)

    def move(self, event):
        if event == 'L':
            self.teta -= 6
        if event == 'R':
            self.teta += 6
        sleep(0.01)



    def move_continuo(self, event):

        self.x += 6*cos(radians(self.teta))
        self.y += 6*sin(radians(self.teta))


        if event == "stop":
            if self.stop == 0:
                self.stop += random.randint(5, 10)
        else:
            self.stop -= 1
        self.update_position_signal.emit({'x': self.x, 'y': self.y, 'stop':
                                          self.stop})
