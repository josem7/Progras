from backend import *

import sys

from PyQt5.QtCore import pyqtSignal
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import QObject, pyqtSignal, Qt, QTimer
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget)
from PyQt5.QtGui import QPixmap, QPainter, QPen, QPainterPath, QColor, QImage
from PyQt5.QtWidgets import (QPushButton, QLabel, QLineEdit, QAction)
from PyQt5 import uic

from PyQt5.QtCore import pyqtSignal
from PyQt5.QtWidgets import QWidget, QLabel, QLineEdit, QHBoxLayout, QVBoxLayout
from PyQt5.QtWidgets import QPushButton, QScrollArea
from PyQt5.QtCore import Qt
from time import sleep

import random

qt_name, QtClass = uic.loadUiType("Ventanas/ventana_inicio.ui")
qt_name1, QtClass1 = uic.loadUiType("Ventanas/ventana_inicio_sesion.ui")
qt_name2, QtClass2 = uic.loadUiType("Ventanas/ventana_registro.ui")
qt_name3, QtClass3 = uic.loadUiType("Ventanas/sala_de_espera.ui")

class VentanaInicio(qt_name, QtClass):
    servidor_signal = pyqtSignal(dict)
    terminar_conexion_signal = pyqtSignal()

    def __init__(self, cliente):
        super().__init__()
        # Conectar señales
        self.servidor_signal.connect(cliente.send)
        self.terminar_conexion_signal.connect(cliente.terminar_conexion)
        self.ventana_principal = VentanaJuego(self.servidor_signal,
                                              self.terminar_conexion_signal)

        self.sala_espera = SalaEspera(self.servidor_signal,
                                      self.terminar_conexion_signal,
                                      self.ventana_principal)

        self.setupUi(self)
        self.register_button.clicked.connect(self.registro)
        self.log_button.clicked.connect(self.inicio)
        self.log_in = VentanaLogIn(self,
                                   self.sala_espera,
                                   servidor_signal=self.servidor_signal,
                                   terminar_conexion_signal=
                                   self.terminar_conexion_signal)
        self.v_registro = VentanaRegistro(self, self.servidor_signal,
                                          self.terminar_conexion_signal)

    def inicio(self):
        self.hide()
        self.log_in.show()

    def registro(self):
        self.hide()
        self.v_registro.show()

    def mostrar(self):
        self.sala_espera.mostrar()


class VentanaLogIn(qt_name1, QtClass1):
    def __init__(self, ventana_i, ventana_principal,
                servidor_signal, terminar_conexion_signal):
        super().__init__()
        self.setupUi(self)
        self.ventana_anterior = ventana_i

        self.servidor_signal = servidor_signal
        self.terminar_conexion_signal = terminar_conexion_signal
        self.nombre_usuario = ""

        self.volver.clicked.connect(self.volver_inicio)
        self.log_button.clicked.connect(self.log_in)

        self.ventana_principal = ventana_principal

    def volver_inicio(self):
        self.hide()
        self.ventana_anterior.show()

    def log_in(self):
        if cargar_usuario(self.usuario.text(), self.cont.text()):
            self.mensaje.setText(f'Nombre Valido')

            self.nombre_usuario = self.usuario.text()

            mensaje = {"status": "nuevo_usuario",
                       "data": self.nombre_usuario}

            self.servidor_signal.emit(mensaje)
            sleep(0.1)
            self.ventana_principal.agregar_usuario(self.nombre_usuario)

            #self.ventana_chat.show()

            #self.ventana_juego.show()
            #self.ventana_principal.agregar_usuario(self.nombre_usuario)

            self.ventana_principal.show()
            self.enviar_señal()
            self.close()
        else:
            self.mensaje.setText(f'Usuario o contraseña invalido')

    def enviar_señal(self):
        mensaje = {"status": "log_in",
                   "data": {"usuario": self.nombre_usuario,
                            "contenido": ""}}
        self.servidor_signal.emit(mensaje)


class VentanaRegistro(qt_name2, QtClass2):
    def __init__(self, ventana, servidor_signal, terminar_conexion_signal):
        super().__init__()

        self.setupUi(self)
        self.ventana_anterior = ventana

        self.servidor_signal = servidor_signal
        self.terminar_conexion_signal = terminar_conexion_signal

        self.volver.clicked.connect(self.volver_inicio)
        self.register_button.clicked.connect(self.registrarse)

    def volver_inicio(self):
        self.hide()
        self.ventana_anterior.show()

    def registrarse(self):
        if self.cont.text() == self.repcont.text():
            if registro(self.usuario.text(), self.cont.text()):
                self.mensaje.setText(f'Usuario creado corectamente')
            else:
                self.mensaje.setText(f'Usuairo Invalido (No puede contener ",'
                                     f'" o ya existe)')
        else:
            self.mensaje.setText(f'contraseñas no coinsiden')


class VentanaJuego(QWidget):
    move_character_signal = pyqtSignal(str)

    def __init__(self, servidor_signal,
                 terminar_conexion_signal, parent=None, *args, **kwargs):
        super(VentanaJuego, self).__init__(parent)
        self.init_GUI()
        self.setStyleSheet("background-color: black;")
        self.setGeometry(0, 0, 900, 900)

        x = random.randint(50, 450)
        y = random.randint(50, 450)

        self.nombre_usuario = ""
        self.servidor_signal = servidor_signal

        self.terminar_conexion_signal = terminar_conexion_signal
        self.ventana_chat = ""
        self.widget = ""

        self.background = QLabel(self)
        self.background.setPixmap(QPixmap('sprites/map.png'))
        self.background.setStyleSheet("background-color: transparent")
        self.background.setGeometry(0, 0, 600, 600)



        self.backend_character = Character(self, x, y)

        self.move_character_signal.connect(self.backend_character.move)

        self.front_character = QLabel(self)
        self.front_character.setPixmap(QPixmap('sprites/punto.png'))
        self.front_character.move(x-3, y-2)


        self.path = QPainterPath()
        self.path.moveTo(x-3, y-3)

        self.otro_path = QPainterPath()

        self.q = QPainter(self)
        self.q.setPen(QPen(Qt.white, 30, Qt.SolidLine))

        self.posisiones = [(x, y)]
        self.p_actual = (x, y)
        self.p_antigua = (x, y)

        self.timer = QTimer()
        self.timer.timeout.connect(self._update)
        self.corriendo = False
        self.vivo = True

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Space:
            if not self.corriendo:
                if self.vivo:
                    self.timer.start(50)
                    self.corriendo = True
                mensaje = {"status": "jugar",
                           "data": {"usuario": self.nombre_usuario,
                                    "contenido":""}}
                self.servidor_signal.emit(mensaje)
            else:
                mensaje = {"status": "jugar",
                           "data": {"usuario": self.nombre_usuario,
                                    "contenido":""}}
                self.servidor_signal.emit(mensaje)
                self.timer.stop()
                self.corriendo = False

        if e.key() == Qt.Key_Left:
            if self.vivo:
                self.move_character_signal.emit('L')
        if e.key() == Qt.Key_Right:
            if self.vivo:
                self.move_character_signal.emit('R')

    def _update(self):
        x = random.random()
        if x < 0.01:
            self.backend_character.move_continuo("stop")
        else:
            self.backend_character.move_continuo("")

        mensaje = {"status": "path", "data": {"usuario": self.nombre_usuario,
                                                 "contenido":
                                                 [self.p_actual,
                                                  self.p_antigua]}}
        self.servidor_signal.emit(mensaje)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setPen(QPen(Qt.red, 3.5))
        painter.drawPath(self.path)

        painter1 = QPainter(self)
        painter1.setPen(QPen(Qt.blue, 3.5))
        painter1.drawPath(self.otro_path)

    def update_position(self, event):
        stop = event["stop"]
        a = self.backend_character.collision()
        if stop == 0:
            self.path.lineTo(event['x'], event['y'])
            self.p_antigua = self.p_actual
            self.p_actual = round(event['x'], 5), round(event['y'], 5)
            for x in a:
                if x in self.posisiones:
                    self.timer.stop()
                    self.vivo = False
                if self.path.intersects(self.otro_path):
                    self.vivo = False
                    self.timer.stop()
            self.posisiones += a

        elif stop == 1:
            self.p_actual = round(event['x'], 5), round(event['y'], 5)
            self.p_antigua = self.p_actual
            self.path.moveTo(event['x'], event['y'])
        self.front_character.move(event['x']-7, event['y']-3)
        self.update()

    def init_GUI(self):

        self.setGeometry(240, 20, 600, 600)

    def agregar_usuario(self, usuario):
        self.nombre_usuario = usuario

    def agregar_ventana_chat(self, ventana_chat):
        self.ventana_chat = ventana_chat
        self.widget1 = self.ventana_chat

    def actualizar_juego(self, contenido, usuario):
        if usuario != self.nombre_usuario:
            self.otro_path.moveTo(contenido[1][0], contenido[1][1])
            self.otro_path.lineTo(contenido[0][0], contenido[0][1])

            self.update()

    def jugar(self):
        if not self.corriendo:
            self.timer.start(50)
            self.corriendo = True
        else:
            self.timer.stop()
            self.corriendo = False

class VentanaChat(QWidget):

    def __init__(self, servidor_signal, terminar_conexion_signal,
                 parent=None, *args, **kwargs):
        super(VentanaChat, self).__init__(parent)
        # Señales
        self.servidor_signal = servidor_signal
        self.terminar_conexion_signal = terminar_conexion_signal

        # Log
        self.chat_log = ""

        # instancias de UI
        self.setGeometry(0, 20, 640, 480)


        self.chat_log_label = QLabel("", self)
        chat_log_label_font = self.chat_log_label.font()
        chat_log_label_font.setPointSize(12)
        self.chat_log_label.setFont(chat_log_label_font)
        self.chat_log_label.setStyleSheet("color: darkblue")

        self.users_scroll = QScrollArea(self)
        self.users_scroll.setWidgetResizable(True)
        self.users_scroll.setStyleSheet("background-color: transparent")

        self.usuario_line_edit = QLineEdit("", self)
        usuario_line_edit_font = self.usuario_line_edit.font()
        usuario_line_edit_font.setPointSize(12)
        self.usuario_line_edit.setFont(usuario_line_edit_font)
        self.usuario_line_edit.setStyleSheet("color: darkblue")

        self.boton_usuario = QPushButton("\t\tEnviar\t\t", self)
        boton_usuario_font = self.boton_usuario.font()
        boton_usuario_font.setBold(True)
        boton_usuario_font.setPointSize(12)
        self.boton_usuario.setFont(boton_usuario_font)
        self.boton_usuario.setStyleSheet(
             "QPushButton{color: darkblue; background: transparent; border: "
             "2px solid darkblue; border-radius: 8px}"
             "QPushButton:pressed{color: #fcf7e3; background-color: darkblue}")


        # Alineación de UI
        self.init_setup()

    def init_setup(self):
        self.chat_log_label.setGeometry(90, 80, 300, 300)
        self.users_scroll.setWidget(self.chat_log_label)
        self.users_scroll.setGeometry(90, 80, 300, 300)
        self.chat_log_label.setAlignment(Qt.AlignTop)
        self.usuario_line_edit.setGeometry(90, 400, 350, 50)
        self.usuario_line_edit.setFocus()
        self.boton_usuario.setGeometry(475, 400, 80, 50)

    def manejo_boton(self):
        mensaje = {"status": "mensaje", "data": {"usuario": self.nombre_usuario,
                                                 "contenido":
                                                 self.usuario_line_edit.text()}}
        self.servidor_signal.emit(mensaje)
        self.usuario_line_edit.setText("")

    def actualizar_chat(self, contenido):
        self.chat_log += f"{contenido}\n"
        self.chat_log_label.setText(self.chat_log)

class SalaEspera(qt_name3, QtClass3):

    def __init__(self, servidor_signal, terminar_conexion_signal,
                 ventana_juego):
        super().__init__()
        self.setupUi(self)

        # Señales
        self.servidor_signal = servidor_signal
        self.terminar_conexion_signal = terminar_conexion_signal
        self.ventana_juego = ventana_juego
        self.nombre_usuario = ""

        self.boton_usuario.clicked.connect(self.manejo_boton)
        self.boton_comenzar.clicked.connect(self.empezar_juego)

        self.chat_log_label = QLabel("", self)
        chat_log_label_font = self.chat_log_label.font()
        chat_log_label_font.setPointSize(12)
        self.chat_log_label.setFont(chat_log_label_font)
        self.chat_log_label.setStyleSheet("color: darkblue")

        self.users_scroll = QScrollArea(self)
        self.users_scroll.setWidgetResizable(True)
        self.users_scroll.setStyleSheet("background-color: transparent")

        self.players = []
        self.admin = False
        self.chat_log = ""
        self.init_setup()



    def manejo_boton(self):
        mensaje = {"status": "mensaje", "data": {"usuario": self.nombre_usuario,
                                                 "contenido":
                                                 self.usuario_line_edit.text()}}
        self.servidor_signal.emit(mensaje)
        self.usuario_line_edit.setText("")

    def actualizar_chat(self, contenido):
        self.chat_log += f"{contenido}\n"
        self.chat_log_label.setText(self.chat_log)

    def actualizar_jugadores(self):
        try:
            self.jugador1.setText(self.players[0])
        except IndexError:
            pass
        try:
            self.jugador2.setText(self.players[1])
        except IndexError:
            pass
        try:
            self.jugador3.setText(self.players[2])
        except IndexError:
            pass
        try:
            self.jugador4.setText(self.players[3])
        except IndexError:
            pass

    def agregar_jugadores(self, jugadores):
        self.players = jugadores
        self.actualizar_jugadores()

    def empezar_juego(self):
        mensaje = {"status": "comenzar","data": {"usuario": self.nombre_usuario,
                                                 "contenido": ""}}
        self.servidor_signal.emit(mensaje)


    def contador(self):
        for i in range(0, 5):
            self.cuenta_regresiva.setText(f"Juego comineza en {5-i}")
            sleep(1)

    def agregar_usuario(self, usuario):
        self.nombre_usuario = usuario
        self.ventana_juego.agregar_usuario(usuario)

    def mostrar(self):
        self.close()
        self.ventana_juego.show()
        print("AAAAAa")


    def init_setup(self):
        self.chat_log_label.setGeometry(10, 180, 291, 281)
        self.users_scroll.setWidget(self.chat_log_label)
        self.users_scroll.setGeometry(10, 180, 291, 281)
"""
if __name__ == '__main__':
    app = QApplication([])
    form = VentanaInicio()
    form.show()
    sys.exit(app.exec_())
"""
