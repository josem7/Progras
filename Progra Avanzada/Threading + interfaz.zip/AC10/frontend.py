# Acá va lo relacionado con la GUI.
from backend import nombre_valido, Character

import sys

from PyQt5.QtCore import pyqtSignal
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import QObject, pyqtSignal, Qt
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget)
from PyQt5.QtWidgets import (QHBoxLayout, QVBoxLayout)
from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import (QPushButton, QLabel, QLineEdit, QAction)


class VentanaPacMan(QWidget):
    move_character_signal = pyqtSignal(str)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, *kwargs)
        self.init_GUI()
        self._frame = 1
        self.setGeometry(560, 560, 615, 615)

        self.background = QLabel(self)
        self.background.setPixmap(QPixmap('sprites/map.png'))

        self.backend_character = Character(self, 330, 485)
        self.move_character_signal.connect(self.backend_character.move)

        self.front_character = QLabel(self)
        self.front_character.setPixmap(QPixmap('sprites/pacman_D_1.png'))
        self.front_character.move(330, 485)


    @property
    def frame(self):
        return self._frame

    @frame.setter
    def frame(self, value):
        if value > 3:
            self._frame = 1
        else:
            self._frame = value

    def keyPressEvent(self, e):
        self.frame += 1
        if e.key() == Qt.Key_Right:
            self.front_character.setPixmap(
                QPixmap(f'sprites/pacman_R_{self.frame}.png'))
            self.move_character_signal.emit('D')
        if e.key() == Qt.Key_Left:
            self.front_character.setPixmap(
                QPixmap(f'sprites/pacman_L_{self.frame}.png'))
            self.move_character_signal.emit('A')
        if e.key() == Qt.Key_Down:
            self.front_character.setPixmap(
                QPixmap(f'sprites/pacman_D_{self.frame}.png'))
            self.move_character_signal.emit('S')
        if e.key() == Qt.Key_Up:
            self.front_character.setPixmap(
                QPixmap(f'sprites/pacman_U_{self.frame}.png'))
            self.move_character_signal.emit('W')


    def update_position(self, event):
        self.front_character.move(event['x'], event['y'])

    def init_GUI(self):

        self.setGeometry(600, 600, 600, 600)


class VentanaInicio(QWidget):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, *kwargs)
        self.init_GUI()

    def init_GUI(self):
        """
        Este método configura todos los widgets de la ventana.
        """
        self.setGeometry(100, 100, 300, 300)
        self.label1 = QLabel('Nombre:', self)
        self.label1.move(10, 15)
        self.edit1 = QLineEdit('', self)
        self.edit1.setGeometry(45, 15, 100, 20)
        self.boton1 = QPushButton('Submit', self)
        self.boton1.clicked.connect(self.boton_callback)
        self.boton1.resize(self.boton1.sizeHint())
        self.label2 = QLabel('', self)

        """
        Creamos el layout horizontal y agregamos los widgets mediante el
        método addWidget(). El método addStretch() nos permite incluir
        opcionalmente espaciadores.
        """
        hbox = QHBoxLayout()
        hbox.addStretch(1)
        hbox.addWidget(self.label1)
        hbox.addWidget(self.edit1)
        hbox.addWidget(self.boton1)
        hbox.addStretch(1)

        hbox1 = QHBoxLayout()

        hbox1.addWidget(self.label2)

        vbox = QVBoxLayout()
        vbox.addStretch(2)
        vbox.addLayout(hbox)
        vbox.addStretch(1)
        vbox.addLayout(hbox1)
        vbox.addStretch(1)
        self.setLayout(vbox)

    def boton_callback(self):

        if nombre_valido(self.edit1.text()):
            self.label2.setText(f'Nombre Valido')
            self.open_window()
        else:
            self.label2.setText(f'Nombre invalido')

    def open_window(self):
        self.hide()
        self.maingame = VentanaPacMan()
        self.maingame.show()




if __name__ == '__main__':
    app = QApplication([])
    form = VentanaInicio()
    form.show()
    sys.exit(app.exec_())
